import puppeteer from 'puppeteer-core';
const [,,out,q='',views='front'] = process.argv;
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
const p = await b.newPage(); await p.setViewport({width:900,height:900});
await p.goto('http://localhost:4173/'+q,{waitUntil:'load'});
await p.waitForFunction(()=>window.__mwt && document.body.innerText.includes('ready')||window.__mwt,{timeout:90000});
await new Promise(r=>setTimeout(r,2500));
const V={
 front:[[0,1.40,0.62],[0,1.34,0.1]],
 fronthi:[[0,1.45,0.40],[0,1.38,0.08]],
 back:[[0,1.45,-0.45],[0,1.38,-0.02]],
 side:[[0.55,1.40,0.05],[0,1.38,0.02]],
 q:[[0.35,1.45,0.40],[0,1.36,0.05]],
 full:[[0,1.0,2.4],[0,0.95,0]],
};
for (const v of views.split(',')) {
  const [pos,tgt]=V[v];
  await p.evaluate((pos,tgt)=>{const m=window.__mwt;m.camera.position.set(...pos);m.controls.target.set(...tgt);m.controls.update();m.render&&m.render();},pos,tgt);
  await new Promise(r=>setTimeout(r,700));
  await p.screenshot({path:out+'_'+v+'.png'});
}
await b.close();
