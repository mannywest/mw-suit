import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { REGIONS, FINISHES, MODEL_FILE, UV_CM_PER_UNIT, type Fabric, type Config, type Ticket } from './config';
import { splitLapel } from './lapel';

const view = document.getElementById('view')!, panel = document.getElementById('panel')!, status = document.getElementById('status')!;
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.toneMapping = THREE.NeutralToneMapping;
view.appendChild(renderer.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color(0x15161a);
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
const key = new THREE.DirectionalLight(0xffffff, 1.2); key.position.set(2, 3, 3); scene.add(key);
const camera = new THREE.PerspectiveCamera(30, 1, 0.05, 50);
const controls = new OrbitControls(camera, renderer.domElement); controls.enableDamping = true;

const state = { fabrics: {} as Record<string, string>, visible: {} as Record<string, boolean> };
const meshes: Record<string, THREE.Mesh> = {};
const baseMats: Record<string, THREE.MeshPhysicalMaterial> = {};
const texCache = new Map<string, THREE.Texture>();
let library: Fabric[] = [];
let lapelMat: THREE.MeshPhysicalMaterial;
const LAPEL_STYLES: { id: string; name: string; mat: string }[] = [{ id: 'notch', name: 'Notch lapel', mat: 'Jacket_Lapel' }, { id: 'peak', name: 'Peak lapel', mat: 'Jacket_Lapel_Peak' }];
const styleMeshes: Record<string, THREE.Mesh> = {}; let lapelStyle = 'notch';
function setLapelStyle(id: string) { if (!styleMeshes[id]) return; lapelStyle = id; for (const [k, m] of Object.entries(styleMeshes)) m.visible = k === id && state.visible['jacket_body'] !== false; render(); }

function fabricTexture(f: Fabric): THREE.Texture {
  let t = texCache.get(f.id); if (t) return t;
  t = new THREE.TextureLoader().load(import.meta.env.BASE_URL + 'fabrics/' + f.file.replace('fabrics/', ''), () => render());
  t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  t.channel = 1; // TEXCOORD_1: near-metric, warp-aligned (V vertical)
  // Texture is a 2x2 mirrored tile covering 2x the cropped swatch; tileCm is the physical size of that whole tile.
  const r = UV_CM_PER_UNIT / f.tileCm; t.repeat.set(r, r);
  texCache.set(f.id, t); return t;
}

function applyFabric(regionId: string, fabricId: string) {
  const requested = fabricId;
  const m = regionMat(regionId);
  if (regionId === 'jacket_lapel' && fabricId === 'match') fabricId = state.fabrics.jacket_body;
  const fin = FINISHES.find(x => x.id === fabricId);
  if (fin) {
    m.map = null; m.color.set(fin.color); m.metalness = 0; m.roughness = fin.roughness; m.metalnessMap = null; m.roughnessMap = null;
    m.sheen = fin.sheen; m.sheenRoughness = 0.5; m.sheenColor.set(0x666677); m.envMapIntensity = 0.6;
    m.bumpMap = fin.weave ? satinWeave() : null; m.bumpScale = 0.35;
  } else {
    const f = library.find(x => x.id === fabricId)!, t = fabricTexture(f);
    m.sheen = 0; m.envMapIntensity = 1; m.map = t; m.color.set(0xffffff); m.metalnessMap = null; m.roughnessMap = null; m.metalness = 0; m.roughness = 0.88; m.bumpMap = t; m.bumpScale = 0.6;
  }
  m.needsUpdate = true;
  state.fabrics[regionId] = requested;
  if (regionId === 'jacket_body' && state.fabrics.jacket_lapel === 'match') applyFabric('jacket_lapel', 'match');
  render();
}
let weaveTex: THREE.Texture | null = null;
function satinWeave(): THREE.Texture { // fine diagonal twill so satin is not a flat glossy sheet; ~4 mm period on TEXCOORD_1
  if (weaveTex) return weaveTex;
  const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d')!;
  g.fillStyle = '#808080'; g.fillRect(0, 0, 64, 64);
  for (let i = -64; i < 128; i += 4) { g.strokeStyle = i % 8 ? '#a0a0a0' : '#606060'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 64, 64); g.stroke(); }
  weaveTex = new THREE.CanvasTexture(c); weaveTex.wrapS = weaveTex.wrapT = THREE.RepeatWrapping; weaveTex.channel = 1; weaveTex.repeat.set(8, 8);
  return weaveTex;
}
function regionMat(regionId: string): THREE.MeshPhysicalMaterial {
  return regionId === 'jacket_lapel' ? lapelMat : baseMats[REGIONS.find(r => r.id === regionId)!.mesh];
}
const waistParts: THREE.Mesh[] = [], tieParts: THREE.Mesh[] = []; let tieBox = new THREE.Box3();
function splitMesh(bm: THREE.Mesh, rule: (c: THREE.Vector3) => number, n: number): (THREE.Mesh | null)[] {
  const g = bm.geometry, pos = g.getAttribute('position'), ia = g.getIndex()!.array, buckets: number[][] = Array.from({ length: n }, () => []);
  bm.updateWorldMatrix(true, false); const v = new THREE.Vector3(), cen = new THREE.Vector3();
  for (let t = 0; t < ia.length; t += 3) { // classify by world-space centroid (positions may be quantized + node-scaled)
    cen.set(0, 0, 0); for (let k = 0; k < 3; k++) cen.add(v.fromBufferAttribute(pos, ia[t + k]).applyMatrix4(bm.matrixWorld)); cen.multiplyScalar(1 / 3);
    buckets[rule(cen)].push(ia[t], ia[t + 1], ia[t + 2]);
  }
  g.setIndex(buckets[0]);
  return buckets.map((b, i) => {
    if (i === 0 || !b.length) return null;
    const g2 = new THREE.BufferGeometry(); for (const k of Object.keys(g.attributes)) g2.setAttribute(k, g.getAttribute(k)); g2.setIndex(b);
    const m = new THREE.Mesh(g2, bm.material); m.position.copy(bm.position); m.quaternion.copy(bm.quaternion); m.scale.copy(bm.scale); bm.parent!.add(m); return m;
  });
}
function setVisible(regionId: string, v: boolean) {
  if (regionId === 'waistcoat_body') waistParts.forEach(m => (m.visible = v));
  if (regionId === 'tie') tieParts.forEach(m => (m.visible = !v));
  meshes[REGIONS.find(r => r.id === regionId)!.mesh].visible = v; state.visible[regionId] = v; render();
}
function download(name: string, obj: unknown) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' }));
  a.download = name; a.click();
}
function currentConfig(): Config {
  return { schema: 'mwt.config', version: 1, model: MODEL_FILE.split('/').pop()!, created: new Date().toISOString(), fabrics: { ...state.fabrics }, visible: { ...state.visible }, lapel_style: lapelStyle };
}
function exportConfig() { download('mw-tailleur-config.json', currentConfig()); }
function exportTicket() {
  const c = currentConfig(), lines: Ticket['lines'] = [];
  for (const r of REGIONS.filter(x => x.fabric)) {
    if (c.visible[r.id] === false) continue;
    let id = c.fabrics[r.id]; if (id === 'match') id = c.fabrics.jacket_body;
    const f = library.find(x => x.id === id), fin = FINISHES.find(x => x.id === id);
    lines.push({ region: r.id, label: r.label, fabricId: id, fabricName: f?.name ?? fin?.name ?? id, code: f?.code ?? null, supplier: f?.supplier ?? '', weightGsm: f?.weightGsm ?? null, source: f?.source ?? (fin ? 'finish preset (no book swatch)' : ''), finish: !!fin, needsReview: !!f && (!f.code || f.review.length > 0) });
  }
  const t: Ticket = { schema: 'mwt.ticket', version: 1, ticketId: 'MWT-' + Date.now().toString(36).toUpperCase(), created: c.created, model: c.model, lines,
    omitted: REGIONS.filter(r => r.toggle && c.visible[r.id] === false).map(r => r.id),
    notes: 'Lapel style: ' + (LAPEL_STYLES.find(x => x.id === lapelStyle)?.name ?? lapelStyle) + '. Preview-derived spec: fabrics and garment parts only. No measurements. Lines with needsReview have an unconfirmed label code. Colour on screen is approximate.' };
  download(t.ticketId + '-ticket.json', t);
}
function loadConfig(c: Config) {
  if (c?.schema !== 'mwt.config' || c.version !== 1) throw new Error('Not an MW Tailleur config v1');
  for (const [r, f] of Object.entries(c.fabrics)) {
    const ok = r === 'jacket_lapel' ? (f === 'match' || FINISHES.some(x => x.id === f) || library.some(x => x.id === f)) : library.some(x => x.id === f);
    if (REGIONS.some(x => x.id === r && x.fabric) && ok) applyFabric(r, f);
  }
  for (const [r, v] of Object.entries(c.visible)) if (REGIONS.some(x => x.id === r && x.toggle)) setVisible(r, !!v);
  if ((c as any).lapel_style) setLapelStyle(String((c as any).lapel_style));
  buildPanel();
}
function render() { renderer.render(scene, camera); }
function resize() { const w = view.clientWidth, h = view.clientHeight; renderer.setSize(w, h); camera.aspect = w / h; camera.updateProjectionMatrix(); render(); }
addEventListener('resize', resize); controls.addEventListener('change', render);
(function loop() { requestAnimationFrame(loop); controls.update(); })();

const thumbUrl = (f: Fabric) => `url(${import.meta.env.BASE_URL}${f.thumb})`;
const ADMIN = new URLSearchParams(location.search).get('admin') === '1';
function label(r: string) { const id = state.fabrics[r]; if (r === 'jacket_lapel' && id === 'match') return 'Match jacket'; const f = library.find(x => x.id === id); return f ? (f.code ? f.code + ' · ' : '') + f.name : FINISHES.find(x => x.id === id)?.name ?? id; }
function openCatalog(regionId: string) {
  const ov = document.createElement('div'); ov.style.cssText = 'position:fixed;inset:0;background:#000c;z-index:9;display:flex;justify-content:center;align-items:center';
  const box = document.createElement('div'); box.style.cssText = 'background:#1d1f25;width:min(900px,96vw);height:min(80vh,700px);border-radius:10px;display:flex;flex-direction:column;padding:12px;gap:8px';
  const bar = document.createElement('div'); bar.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;align-items:center';
  const q = document.createElement('input'); q.placeholder = 'Search code or name'; q.style.cssText = 'flex:1;min-width:140px;padding:6px;background:#111;color:#eee;border:1px solid #444;border-radius:4px';
  const sel = (opts: string[]) => { const e = document.createElement('select'); e.style.cssText = 'padding:6px;background:#111;color:#eee;border:1px solid #444;border-radius:4px'; e.innerHTML = opts.map(o => `<option>${o}</option>`).join(''); return e; };
  const pat = sel(['all patterns', 'plain', 'patterned']), fam = sel(['all colours', ...new Set(library.map(f => f.family))]), tone = sel(['all tones', 'dark', 'light']);
  const close = document.createElement('button'); close.textContent = '✕'; close.className = 'act'; close.style.margin = '0'; close.onclick = () => ov.remove();
  bar.append(q, pat, fam, tone); if (ADMIN) { const ex = document.createElement('button'); ex.textContent = 'Export manifest'; ex.className = 'act'; ex.style.margin = '0'; ex.onclick = () => download('manifest.json', { version: 2, fabrics: library }); bar.append(ex); }
  bar.append(close);
  const grid = document.createElement('div'); grid.style.cssText = 'overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(' + (ADMIN ? 180 : 92) + 'px,1fr));gap:8px;align-content:start;flex:1';
  const draw = () => {
    grid.innerHTML = '';
    const term = q.value.toLowerCase();
    const pick = (id: string) => { applyFabric(regionId, id); ov.remove(); buildPanel(); };
    if (regionId === 'jacket_lapel') for (const o of [{ id: 'match', name: 'Match jacket', css: 'linear-gradient(135deg,#334 50%,#556 50%)' }, ...FINISHES.map(x => ({ id: x.id, name: x.name, css: '#' + x.color.toString(16).padStart(6, '0') }))]) {
      if (term && !o.name.toLowerCase().includes(term)) continue;
      const b = document.createElement('button'); b.title = o.name; b.style.cssText = `height:60px;border:1px solid #444;border-radius:6px;background:${o.css};color:#fff;font-size:10px;cursor:pointer`; b.textContent = o.name; b.onclick = () => pick(o.id); grid.appendChild(b);
    }
    for (const f of library) {
      if (term && !(f.name + ' ' + (f.code ?? '')).toLowerCase().includes(term)) continue;
      if (pat.value !== 'all patterns' && f.pattern !== pat.value) continue; if (fam.value !== 'all colours' && f.family !== fam.value) continue; if (tone.value !== 'all tones' && f.tone !== tone.value) continue;
      const c = document.createElement('div'); c.style.cssText = 'font-size:10px;color:#aaa;text-align:center';
      const b = document.createElement('button'); b.style.cssText = `width:100%;height:70px;border:2px solid ${f.review.length ? '#a55' : 'transparent'};border-radius:6px;background:${thumbUrl(f)};background-size:cover;cursor:pointer`; b.title = f.source + (f.review.length ? ' · review: ' + f.review.join(', ') : ''); b.onclick = () => pick(f.id);
      c.append(b, f.code ?? 'p' + f.page + ' (no code)');
      if (ADMIN) {
        const ci = document.createElement('input'); ci.value = f.code ?? ''; ci.placeholder = 'code 5838-0850'; ci.style.cssText = 'width:100%;box-sizing:border-box;margin-top:3px;background:#111;color:#eee;border:1px solid #444;font-size:11px';
        ci.onchange = () => { f.code = ci.value.trim() || null; f.review = f.review.filter(x => x !== 'no-label-code' && x !== 'duplicate-code'); };
        const ni = document.createElement('input'); ni.value = f.name; ni.style.cssText = ci.style.cssText; ni.onchange = () => { f.name = ni.value; };
        c.append(ci, ni);
      }
      grid.appendChild(c);
    }
  };
  for (const e of [q, pat, fam, tone]) e.oninput = draw; draw();
  box.append(bar, grid); ov.append(box); ov.onclick = e => { if (e.target === ov) ov.remove(); }; document.body.appendChild(ov);
}
function buildPanel() {
  panel.innerHTML = '<h1>MW Tailleur</h1><small>Order spec · fabric preview, not photorealistic' + (ADMIN ? ' · ADMIN' : '') + `</small><br><small>${library.length} fabrics in catalog</small>`;
  for (const r of REGIONS.filter(x => x.fabric)) {
    panel.insertAdjacentHTML('beforeend', `<h2>${r.label}</h2>`);
    const f = library.find(x => x.id === state.fabrics[r.id]);
    const b = document.createElement('button'); b.style.cssText = 'display:flex;align-items:center;gap:8px;width:100%;padding:6px;background:#111;color:#eee;border:1px solid #444;border-radius:6px;cursor:pointer;text-align:left';
    const sw = document.createElement('span'); sw.style.cssText = 'width:36px;height:36px;border-radius:4px;flex:none;background-size:cover;background:' + (f ? thumbUrl(f) : '#334'); sw.style.backgroundSize = 'cover';
    const tx = document.createElement('span'); tx.style.fontSize = '12px'; tx.textContent = label(r.id);
    b.append(sw, tx); b.onclick = () => openCatalog(r.id); panel.appendChild(b);
  }
  if (Object.keys(styleMeshes).length > 1) {
    panel.insertAdjacentHTML('beforeend', '<h2>Lapel style</h2>');
    const row = document.createElement('div'); row.className = 'sw'; row.style.gap = '6px';
    for (const st of LAPEL_STYLES.filter(x => styleMeshes[x.id])) { const sb = document.createElement('button'); sb.style.cssText = 'flex:1;padding:8px;border-radius:6px;cursor:pointer;width:auto;height:auto;background:' + (st.id === lapelStyle ? '#c9a45c' : '#111') + ';color:' + (st.id === lapelStyle ? '#111' : '#eee') + ';border:1px solid #444;font-weight:600'; sb.textContent = st.name; sb.onclick = () => { setLapelStyle(st.id); buildPanel(); }; row.appendChild(sb); }
    panel.appendChild(row);
  }
  panel.insertAdjacentHTML('beforeend', '<h2>Show</h2>');
  for (const r of REGIONS.filter(x => x.toggle)) {
    const l = document.createElement('label'); const c = document.createElement('input'); c.type = 'checkbox'; c.checked = state.visible[r.id] !== false;
    c.onchange = () => setVisible(r.id, c.checked); l.append(c, ' ' + r.label); panel.appendChild(l);
  }
  const b = document.createElement('button'); b.className = 'act'; b.textContent = 'Export config JSON'; b.onclick = exportConfig; panel.appendChild(b);
  const t = document.createElement('button'); t.className = 'act'; t.style.marginLeft = '6px'; t.textContent = 'Cutting ticket'; t.onclick = exportTicket; panel.appendChild(t);
  const lb = document.createElement('button'); lb.className = 'act'; lb.textContent = 'Load config…'; panel.appendChild(lb);
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json'; inp.hidden = true; panel.appendChild(inp);
  const msg = document.createElement('div'); msg.style.cssText = 'margin-top:8px;font-size:12px;color:#c98'; panel.appendChild(msg);
  lb.onclick = () => inp.click();
  inp.onchange = async () => { try { loadConfig(JSON.parse(await inp.files![0].text())); } catch (e) { msg.textContent = String(e instanceof Error ? e.message : e); } };
}

async function init() {
  const base = import.meta.env.BASE_URL;
  library = (await (await fetch(base + 'fabrics/manifest.json')).json()).fabrics;
  const loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
  let gltf;
  if (import.meta.env.VITE_EMBED) { // single-host build: model shipped as base64 in a .js module (host refuses .glb)
    const { B64 } = await import('./model-embed'); const bin = atob(B64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    gltf = await loader.parseAsync(u.buffer, '');
  } else gltf = await loader.loadAsync(base + (new URLSearchParams(location.search).get('model') ?? MODEL_FILE));
  scene.add(gltf.scene);
  const allMeshes: THREE.Mesh[] = [];
  gltf.scene.traverse(o => { if ((o as THREE.Mesh).isMesh) { allMeshes.push(o as THREE.Mesh); const mn = ((o as THREE.Mesh).material as THREE.Material).name; meshes[mn === 'Jacket_Wool' ? 'Jacket' : o.name] = o as THREE.Mesh; } });
  for (const r of REGIONS) {
    const mesh = meshes[r.mesh]; if (!mesh) { console.warn('missing mesh', r.mesh); continue; }
    if (r.fabric) {
      if (r.id === 'jacket_lapel') continue;
      const origName = (mesh.material as THREE.Material).name, m = (mesh.material as THREE.MeshPhysicalMaterial).clone(); mesh.material = m; baseMats[r.mesh] = m;
      for (const x of allMeshes) if (x !== mesh && (x.material as THREE.Material).name === origName) x.material = m; // e.g. trouser waistband primitive lives in the jacket mesh
      if (r.id === 'jacket_body') {
        // v3 GLB ships a real Jacket_Lapel primitive; with the older v2 GLB fall back to the runtime split.
        const lm = allMeshes.find(x => (x.material as THREE.Material).name === 'Jacket_Lapel');
        if (lm) { lapelMat = (lm.material as THREE.MeshPhysicalMaterial).clone(); lm.material = lapelMat; mesh.userData.lapelNative = true; styleMeshes['notch'] = lm; const pm = allMeshes.find(x => (x.material as THREE.Material).name === 'Jacket_Lapel_Peak'); if (pm) { pm.material = lapelMat; styleMeshes['peak'] = pm; } }
        else { lapelMat = m.clone(); console.log('lapel tris (runtime split)', splitLapel(mesh, m, lapelMat)); }
        if (new URLSearchParams(location.search).get('debug') === 'lapel') { lapelMat.onBeforeCompile = sh => { sh.fragmentShader = sh.fragmentShader.replace('#include <dithering_fragment>', 'gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(1.,0.,0.), 0.7);\n#include <dithering_fragment>'); }; } }
    }
    if (r.toggle) state.visible[r.id] = true;
  }
  // Buttons/threads live in two shared meshes (Buttons, Trim). Split by world-space centroid so waistcoat buttons follow the waistcoat
  // and shirt buttons that sit under the tie are hidden while the tie is shown.
  tieBox = new THREE.Box3().setFromObject(meshes['Tie']);
  // Button column centres (y, z) measured on the v2 model: waistcoat buttons vs shirt buttons share x~0 and nearly the same z, so use nearest centre.
  const WAIST: [number, number][] = [[1.223, 0.135], [1.151, 0.14], [1.081, 0.144], [1.011, 0.144], [0.944, 0.146]];
  const SHIRT: [number, number][] = [[1.422, 0.058], [1.353, 0.09], [1.261, 0.122], [1.164, 0.131], [1.067, 0.135], [0.983, 0.135], [0.967, 0.131], [0.876, 0.121]];
  const near = (a: [number, number][], c: THREE.Vector3) => Math.min(...a.map(([y, z]) => Math.hypot(c.y - y, c.z - z)));
  const inWaist = (c: THREE.Vector3) => Math.abs(c.x) < 0.07 && c.z > 0.1 && c.z < 0.17 && c.y > 0.9 && c.y < 1.3 && near(WAIST, c) < near(SHIRT, c);
  const underTie = (c: THREE.Vector3) => near(SHIRT, c) < near(WAIST, c) && Math.abs(c.x) < 0.04 && c.y > tieBox.min.y - 0.02 && c.y < tieBox.max.y + 0.02 && c.y > 0.9;
  for (const [name, rule] of [['Buttons', (c: THREE.Vector3) => (inWaist(c) ? 1 : 0)], ['Trim', (c: THREE.Vector3) => (inWaist(c) ? 1 : underTie(c) ? 2 : 0)]] as const) {
    const parts = splitMesh(meshes[name], rule, 3); if (parts[1]) waistParts.push(parts[1]); if (parts[2]) tieParts.push(parts[2]);
  }
  // Shirt tails run down inside the trousers and show through the open fly: hide the shirt below the waistband.
  const tails = splitMesh(meshes['Shirt'], c => (c.y < 0.985 ? 1 : 0), 2)[1]; if (tails) tails.visible = false;
  tieParts.forEach(m => (m.visible = false)); // tie shown by default -> shirt buttons under it stay hidden
  const box = new THREE.Box3().setFromObject(gltf.scene), size = box.getSize(new THREE.Vector3()), ctr = box.getCenter(new THREE.Vector3());
  const d = Math.max(size.y / 2 / Math.tan(THREE.MathUtils.degToRad(15)), 1) * 1.15;
  camera.position.set(ctr.x, ctr.y, ctr.z + d); controls.target.copy(ctr); controls.minDistance = d * 0.3; controls.maxDistance = d * 2.5;
  camera.near = d / 100; camera.far = d * 10; camera.updateProjectionMatrix();
  // defaults: jacket + waistcoat + trousers in the first fabric (navy plain)
  const dflt = (library.find(x => x.id === 'p45') ?? library[0]).id;
  state.fabrics = { jacket_body: dflt, jacket_lapel: 'match', waistcoat_body: dflt, trousers_body: dflt };
  setLapelStyle(new URLSearchParams(location.search).get('lapel') ?? 'notch');
  buildPanel(); resize();
  for (const [r, f] of Object.entries(state.fabrics)) applyFabric(r, f);
  const dbg = { size: size.toArray().map(v => +v.toFixed(3)), meshes: Object.keys(meshes) };
  status.textContent = 'ready ' + JSON.stringify(dbg); (window as any).__mwt = { setLapelStyle, meshes, loadConfig, exportTicket, currentConfig, applyFabric, setVisible, state, camera, controls, render };
}
init().catch(e => { status.textContent = 'ERROR ' + e; console.error(e); });
